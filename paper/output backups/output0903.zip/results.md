\cleardoublepage
\chapter{Experimental results}

In this chapter, I present the results of the experiments described in the previous chapter and discuss their outcomes and shortcomings. 
