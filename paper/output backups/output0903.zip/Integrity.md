\cleardoublepage

# Declaration of Academic Integrity


I certify that this seminar paper

``\Arbeitstitel''

is entirely
my own work, except where I have stated full references to the work of others, and
that the material contained in this seminar paper has not previously been submitted
for assessment in any other course of study.
\vspace{0.75cm}

Ich erkläre hiermit, dass ich meine Seminararbeit mit dem Titel

``\Arbeitstitel''

selbstständig und ohne fremde Hilfe angefertigt habe, und dass ich alle
von anderen Autoren wörtliche übernommenen Stellen wie auch die sich an
die Gedankengänge anderer Autoren eng anlehnenden Ausführungen meiner
Arbeit besonders gekennzeichnet und die Quellen zitiert habe.

\vspace{3cm}

\Ort, den \Abgabedatum
