\cleardoublepage

\chapter{Background}
Before delving into previous literature and their relevance to this work and the fields of NLP and language learning as a whole, I detail both voice conversion and accent conversion in order to help better distinguish them. I also go over some common speech technology concepts typically used in these systems at a high level in order to make the current work more accessible to those unfamiliar with the area. Further reference is also provided for those interested in the technical aspects and formalisms. 


# Voice conversion
To properly frame voice conversion, we take a look at \textcite{mohammadi2017} who present a recent overview of the subfield. Following a definition setforth by the authors, voice conversion refers to the transformation of a speech signal of a *source speaker* to make it sound as if it were uttered by a *target speaker* in any chosen fashion with the utterance still being intact. Some of these changes can include changes in emotion, accent, or phonation (whispered/murmured speech). there have been a number of proposed uses for VC, including the transformation of speaker identity (perhaps for voice dubbing), personalized TTS systems, and against biometric voice authentication systems. 

Voice conversion often involves a large number of processes, one of which includes deciding the appropriate type of data. To start, one must decide whether to have parallel or non-parallel speech data. Parallel speech data refers to speech data that has source and reference speakers that say the same utterance, so only the speaker-specific information is different, while non-parallel data would indicate datasets where the utterances are not the same, and thus entail further processes to create a target waveform. Even though parallel corpora are more desirable as it reduces the footprint necessary for conversion, parallel corpora are often curated for specific purposes and are not available in most cases. 

Because of its simplicity, in some cases, researchers have tested making a psuedo-parallel corpus using acoustic clustering when working with non-parallel data \parencite{lorenzo-trueba2018, sundermann2006}.

Other aspects that need to be considered as discussed by \textcite{mohammadi2017} include whether the data is *text-dependent* or *text-independent*. Text-dependent corpora indicate that the data has word or phonetic transcription, which can ease the alignment process during training, while systems using text-independent data would need to find similar speech segments, using a method like acoustic clustering before training. Finally, one minor aspect that is not considered often is the languages of the source speaker and target speaker. Although many systems tend to focus on voice conversion between two native speakers of the same language, systems that aim to convert between two speakers speaking in different languages would have to be wary of potential mapping issues between sounds. This is especially important to consider in terms of accent conversion, which will be discussed in the next section.

Aside from considering these aspects of the corpora, the type of features extracted from the waveforms heavily impact the quality of the conversions. In investigating the most salient features of speaker individuality, previous researchers have concluded that the average spectrum, formants, and average pitch level are the most relevant. Following these conclusions, most VC systems focus on converting these features, and often work at the frame-level (windows of ~20ms), with the assumption that the frame represents a stationary sound. From these frames, there are a number of common *local* features that are extracted to represent the signal. These include the spectral envelope, cepstrum, line spectral frequencies (LSF) and the aforementioned formants. In particular, working with the mel-frequency cepstrum coefficents (MFCCs) are very standard in not just voice conversion systems, but most speech synthesis and recogntion systems in general. These are described in further detail in \autoref{technical-background}. 

On top of these local frame-based features, contextual features can be considered as well, although this would entail further fine-tuning of the features and system. [expand] 

A visual representation that summarizes the voice conversion process can be seen in \autoref{fig:vc-flowchart}, courtesy of \textcite{mohammadi2017}.

\begin{figure}[H]
\centering
\includegraphics[scale=0.25]{img/vc-flowchart.png}
\caption{The training and conversion processes of a typical VC system.}
\label{fig:vc-flowchart}
\end{figure} 


# Accent conversion
Like voice conversion, accent conversion is dedicated to convert the speech of a *source speaker* into sounding like a *target speaker*. However, accent conversion is specifically focused on morphing the *accent* of the speech signal, as opposed to sounding directly like the target speaker. Succinctly stated, "Accent conversion seeks to transform second language L2 utterances to appear as if produced with a native (L1) accent," \parencite{aryal2014a}. Because the confusion that can arise from using the terminology *source speaker* and *target speaker*, the *source speaker* is often referred to as the native or L1 speaker, while the *target speaker* is referred to as the non-native or L2 speaker. This seems somewhat counter-intuitive, but this allows for us to create a voice that retains the non-native speaker's identity and the native speaker's accent \parencite{zhao2018a}.

Accent conversion poses a further challenge on top of (parallel) voice conversion as the audio of the source speaker and target speaker cannot simply be forced-aligned due to the fact that the voice quality and accent of the target speaker would remain \parencite{aryal2014}. This means that accent conversion may require more specialized alignment methods beyond standard frame-by-frame alignment that can help preserve the right speaker information while suppressing the other undesired information. This is further discussed in the follow section on previous work in accent conversion. 


# Technical Background

\subsection{Mel-frequency cepstrum coefficients}
Following \textcite{jurafsky2009}, mel-frequency cepstrum coefficients (MFCCs) allow us to create vectorized representation of the acoustic information. 

This is done by going over the speech signal using _windows_, where each window is assumed to contain a non-changing part of the signal. In order words, each window would roughly contain one phone-- or speech sound. In order to retain all of the necessary information from each part of the signal, the windows often overlap. 

After the signal is separated into different windows, the spectral information can be extracted using a special tool or formula known as the Discrete Fourier Transform. This allows us to find how much energy is in specific frequency bands.

From here the frequencies outputted by the Discrete Fourier Transform are converted onto the _mel_ scale, which is where the _mel_ in Mel-frequency comes from. In short, the mel scale is used to represent human hearing, which is more sensitive to lower pitch sounds (under 1000hz) as compared to higher pitch sounds. 
Afterwards, the _cepstrum_ is calculated in order to separate source information from filter information. From a high level, the source-filter theory says that all sounds come from the glottis (the area around our throat) and below, which contains information common to all speech sounds, such as the fundamental frequency (or pitch) of someone's voice, as well as glottal pulse information. This is compared to the filter, which says that adjusting the vocal tract (e.g. moving the tongue and other articulators) define each individual sounds. By retaining just the filter information, we can model an individual phone. 


A visual representation of the whole MFCC extraction process can be seen in \autoref{fig:vc-flowchart}, taken from \textcite{jurafsky2009}.

\begin{figure}[H]
\centering
\includegraphics[scale=0.22]{img/mfcc-extraction.png}
\caption{The extraction of sequence 39-dimensional MFCC vectors fro a waveform.}
\label{fig:vc-flowchart}
\end{figure} 

\subsection{Gaussian mixture models}
A Gaussian mixture model is a type of probablistic model that aims to represent normally distributed groups within a set. This is based on the idea of the normal, or *Gaussian* distribution, which can be see in [insert figure here]. The Gaussian distribution is characterized by two main features: the mean (the arithmetic average of the data) and the variance (the spread of the data from the mean). The Gaussian distribution is the most important distribution used in probablistic modelling as it has been theorized that the average of independent random variables would look like a normal distribution.

Gaussian mixture models are based on the principle that if a unimodal (one 'peak') dataset can be fit with a Gaussian distribution, then a multimodal (multi 'peak') dataset is just a 'mixture' of smaller Gaussian distributions. 

A common example given to understand the Gaussian distribution and Gaussian mixture models often references height. It is often said that men are taller than women on average, with men being 178cm (5 foot 10 inches), and women being 165cm (5 foot 5 inches). If we used two separate Gaussians to model each gender, we could 'mix' them to model the likelihood of a certain data point (e.g. person) being a male or a female. For example, using two hypothetical variances with the averages previously mentioned, we could see that the likelihood of a person that is 180cm is more likely to be a male than a female. [Put in graph here.]

However, as simple as this sounds the most advantageous point of the Gaussian mixture model is the fact that it is an _unsupervised_ model that can be used when the subpopulations of the data are unknown. Thus, following the previous example of height, a Gaussian mixture model could be used to model the height of the two genders _without_ knowing the gender of each datapoint.

Because it is an _unsupervised_ model, it requires a special method to estimate the appropriate parameters. The most common method used for this is known as _expectation maximization_. This algorithm is used for maximum likelihood estimation. In other words, this algorithm tries to find the most appropriate group for each datapoint by calculating the probability of it being in a certain group and selecting the most likely one. This is done iteratively by initializing reasonable values, and then conducting the expectation (calculating the probability) step and maximization step (maximizing the expectations calculated in the E step) until the algorithms converge. A visual example can be seen in the following figure. [Put figure below.]

This model can be compared to the _k_-means clustering algorithm, as both strive to group different subpopulations. However, the Gaussian Mixture Model can be considered more robust as the number of subpopulations (the _k_ in _k_-means) does not have to be specified [Wait but we have to specify the number of mixtures which IS _k_], nor do the distributions of the clusters have to be circular.  

In speech, Gaussian mixture models can be used for feature extraction in order to represent the various sounds. [This doesn't seem quite right. It seems that GMMs are used within an HMM state to figure out what sound it is]

In speech, Gaussian mixture models can be utilized in conjunction with Hidden Markov Models. In short, Hidden Markov Models are models that consist of _states_ and _transitions_. When utilized in speech recognition, each state represents a potential sound, while the transitions represents the probability or likelihood of the next state (e.g. sound). Gaussian mixture models can be used to represent a sound within a state [check from here].  

\subsection{I-vectors}
Identity vectors, or _i-vectors_ are used as a method to model both the intra-domain and inter-domain variables of speech signals in the same low dimensional space. They are considered one of the more modern methods in speech recognition, compared to the more classic Gaussian mixture models and its modification, Gaussian Mixture Models with universal background model (GMM-UBM), and joint factor analysis. In fact, i-vectors stem from a modification of the joint factor anaylsis method which is explained as the following.

