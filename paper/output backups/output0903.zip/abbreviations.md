\section*{List of Abbreviations}
\addcontentsline{toc}{section}{List of Abbreviations}
\begin{tabular}{ll}
    CAPT    & Computer Assisted Pronunciation Training \\
    CP      & Critical Period \\
    L1/L2    & First and second language \\
    LSTM & Long-short term memory \\
    MFCC & Mel-frequency cepstrum coefficient 
    TTS   & Text-to-speech \\
    
\end{tabular}


\clearpage
