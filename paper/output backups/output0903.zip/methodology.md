\cleardoublepage
\chapter{Design and methodology}

In this chapter, I introduce the dataset and tools utilized in the experiments, and detail the procedures carried out to conduct the accent conversion process.

# Data
The main datasets utilized in the following experiments is the Carnegie Mellon University (CMU) ARCTIC corpus \parencite{kominek2004} and the L2-ARCTIC corpus \parencite{zhao2018}, a non-native English speaker version of the CMU Arctic corpus. 


## CMU ARCTIC corpus
The CMU ARCTIC corpus was originally designed to have good phonetic (specifically diphone) coverage for speech synthesis.



## L2-ARCTIC corpus

The L2-ARCTIC corpus currently contains 10 non-native speakers of Hindi, Korean, Mandarin, Spanish and Arabic, with a male and female speaker for each language. At the time of writing, the curators of the corpus are working to add an additional 10 speakers to the corpus by September 2018. 

The original audio was sampled at 44.1 kHz, with each recording at roughly 3.7 seconds on average. However, in the setting of the experiments described, the audio is downsampled to 16 khz in order to match the quality of the CMU ARCTIC corpus. In total, the duration of the corpus is 11.2 hours, with each speaker recording an average of 67 minutes of audio, or the complete ARCTIC sentence prompt list of 1,132 utterances. However, some speakers did not read all of the sentences and some recordings were removed as they did not have appropriate quality.

In addition to the audio files, the corpus also includes word and phoneme-level transcriptions and manually annotated errors for a 150-sentence subset of the corpus, designed to be used in computer-assisted pronunciation training tools. Within the subset, there are 100 sentences uttered by all speakers, and 50 sentences that contain phonemes that are considered to be difficult based on a speaker's L1. This also includes phone addition, phone substitution, and phone deletion annotations in ARPAbet format, as well as optional comments left by the annotators.  

# Experiment 1: GMM-based accent conversion
This experiment a) is to understand more traditional mapping methods used in voice/accent conversion and b) serves as a baseline to be compared to other innovative methods (e.g Experiment 2).

The methodology for this experiment stems from \textcite{aryal2014}, one of the earlier works done on accent conversion.

## Tools
In order to do GMM-based accent conversion, I utilize the \texttt{nnmnwkii}\footnote{Found at: https://github.com/r9y9/nnmnkwii} Python package which provides fast and easy functions to train voice conversion systems. Alongside this package, I also utilize a number of other packages that \texttt{nnmnkwii} is dependent on, including \texttt{pysptk}, a Python wrapper for the Speech Processing Toolkit, \texttt{pyworld}, a Python wrapper for WORLD, a well-known tool for high-quality speech analysis and acoustic feature extraction, \texttt{librosa}, another package for audio analysis, and the common \texttt{scikit-learn} machine learning package for GMM training.  



# Experiment 2: I-vector based accent conversion

This experiment is motivated by the works presented in \textcite{wu2016} and \textcite{kinnunen2017}. Due to their flexible nature, i-vectors are an appropriate method to capture the representation of an accent in a compact way. 

## Tools
In order to do the i-vector based accent conversion, I first utilized the \texttt{SIDEKIT} Python toolkit to extract the MFCCs, create a GMM (also known as a universal background model) and then the i-vectors to represent each accent. 
