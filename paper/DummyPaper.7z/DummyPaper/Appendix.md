  \newpage
  \begin{appendix}
  \section{Additional figures and tables}

\begin{figure}
	\centering
	\small
	\begin{tabular}{ l r}
	Title&Ranking \\ \hline
	Super Mario 3D World&92.56\\
	Super Smash Bros. for Wii U&92.39\\
	Bayonetta 2&91.38\\
	The Legend of Zelda: The Wind Waker HD& 91.08\\
	Shovel Knight&89.98\\
	Super Mario Maker&89.41\\
	Deus Ex: Human Revolution - Director´s Cut&89.30\\
	Mario Kart 8&88.40\\
	Pikmin 3&86.46\\
	Call of Duty: Black Ops II&86.07\\
	The Legend of Zelda: Twilight Princess HD&85.98\\\hline
	\end{tabular}
	\caption{Superstar titles in generation 8 on Wii U (Rating over 85%)/ Source: Own design based on \cite{Gamerankings2016}}
	\label{tab:wiiusuperstars}
\end{figure}


\end{appendix}
