\section*{List of Abbreviations}
\addcontentsline{toc}{section}{List of Abbreviations}
\begin{tabular}{ll}
    B       & billion(s)\\
	  e.g.	  & 	exemplia gratia (for exampe) \\
    et al.  &   et alia (and others)\\
    etc.    &   et cetera (and so on)\\
    f., ff. &   following page(s)\\
    Ed.   	&   Editor\\
    i.e.    &   id est  (that is)\\
    M     	&   million(s)\\
    no.		&   number \\
    p.  	&	page\\
    Vol.    &   Volume \\
\end{tabular}

*Declaration of Brand Name Usage*

Company, product, and brand names mentioned in this seminar paper may be brand
names or registered trademarks of their respective owners. The use of these brand
names and / or trademarks in this seminar paper does not justify the assumption
that rights of third parties do not apply. All mentioned brand names and trademarks
are subject without restrictions to country-specific protective provisions and the
property rights of their registered owners.

\clearpage
